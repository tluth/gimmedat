import boto3 
from pydantic import AnyUrl
from botocore.client import Config

from .config import appconfig


s3_con = boto3.client(
    "s3",
    appconfig.aws_region,
    config=Config(signature_version="s3v4")
)


def get_post_presigned_url(path: str, file_type: str, file_size_bytes: int) -> AnyUrl:
    return s3_con.generate_presigned_post(
        Bucket=appconfig.files_table_name,
        Key=path,
        ExpiresIn=20,
        Conditions=[
             ["content-length-range", file_size_bytes-100, file_size_bytes+100],
             {"$Content-Type": file_type},
             {"acl": "private"}
        ],
        Fields={
            "$Content-Type": file_type,
            "acl": "private",
        }
    )["url"]


def get_get_presigned_url(key):
    return s3_con.generate_presigned_url(
        "get_object",
        Params={
            "Bucket": appconfig.storage_bucket, 
            "Key": key,
            'ResponseContentDisposition': 'attachment',
            },
        ExpiresIn="360",
    )
